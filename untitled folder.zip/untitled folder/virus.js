function trash(){
    window.open('know your place virus.html');
}
document.addEventListener('load', trash(), true);